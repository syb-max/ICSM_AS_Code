#!/usr/bin/env python3
"""Evaluate Power-Top16, Correlation-Greedy and Capacity-Greedy on a prepared HDF5 split."""
from __future__ import annotations
import argparse,csv,json,hashlib
from pathlib import Path
import numpy as np
from icsm_as.core.physics_data import PhysicsDataset
from icsm_as.core.capacity_teacher import capacity_validated
from icsm_as.models.baselines.power_top16 import power_topk
from icsm_as.models.baselines.correlation_greedy import correlation_greedy
from icsm_as.models.baselines.capacity_greedy import capacity_greedy
from icsm_as.evaluation.metrics import normalized_capacity_ratio,hq_referenced_ratio

def _sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('--data_h5',required=True);p.add_argument('--split',type=int,default=1,choices=[1,2]);p.add_argument('--output',required=True);p.add_argument('--selection_manifest');a=p.parse_args()
 if a.split==2:
  if not a.selection_manifest: raise ValueError('Test split requires the frozen ICSM-AS/baseline selection manifest')
  manifest=json.loads(Path(a.selection_manifest).read_text(encoding='utf-8'))
  expected=manifest.get('data_sha256') or manifest.get('training_labels_sha256')
  if expected!=_sha(a.data_h5): raise ValueError('Prepared data SHA256 does not match frozen selection manifest')
  lock=Path(a.output).with_suffix('.test_opened.json'); lock.parent.mkdir(parents=True,exist_ok=True)
  with lock.open('x',encoding='utf-8') as f: json.dump({'selection_manifest':str(Path(a.selection_manifest).resolve()),'data_sha256':expected},f,indent=2)
 ds=PhysicsDataset(a.data_h5,split=a.split,require_teacher=(a.split!=2));rows=[]
 for i in range(len(ds)):
  s=ds[i];g=s['G_tx_real'].numpy()+1j*s['G_tx_imag'].numpy();rho=float(s['snr_reference_linear']);k=ds.n_sel
  greedy,_=capacity_greedy(g,rho,k)
  methods={'Power-Top16':power_topk(g,k),'Correlation-Greedy':correlation_greedy(g,k),'Capacity-Greedy':greedy}
  for name,idx in methods.items():
   cap=capacity_validated(g,rho,idx,k);gc=float(s['greedy_capacity']) if 'greedy_capacity' in s else capacity_validated(g,rho,greedy,k)
   hq=float(s['hq_capacity']) if 'hq_capacity' in s else float('nan')
   rows.append({'sample_id':int(s['sample_id']),'site_id':int(s['site_id']),'snr_reference_db':float(s['snr_reference_db']),
    'method':name,'capacity':cap,'NCR':normalized_capacity_ratio(cap,gc),'R_C_HQ':hq_referenced_ratio(cap,hq) if np.isfinite(hq) and hq>0 else ''})
 Path(a.output).parent.mkdir(parents=True,exist_ok=True)
 with open(a.output,'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 ds.close();print(f'Wrote {len(rows)} rows to {a.output}')
if __name__=='__main__':main()
