#!/usr/bin/env bash
set -euo pipefail
DATA_H5=${1:?Usage: freeze_and_test_baselines.sh DATA_H5 BASELINE_RUNS_ROOT}
ROOT=${2:?Usage: freeze_and_test_baselines.sh DATA_H5 BASELINE_RUNS_ROOT}
for RUN in "$ROOT"/*; do
  [[ -d "$RUN" && -f "$RUN/best.pt" && -f "$RUN/run_manifest.json" ]] || continue
  NAME=$(basename "$RUN")
  MANIFEST="$RUN/selection_manifest.json"
  if [[ ! -f "$MANIFEST" ]]; then
    PYTHONPATH=src python scripts/freeze_baseline.py --run_dir "$RUN" --output "$MANIFEST"
  fi
  PYTHONPATH=src python scripts/evaluate_neural_baseline.py \
    --checkpoint "$RUN/best.pt" --data_h5 "$DATA_H5" --split 2 \
    --selection_manifest "$MANIFEST" --output "$RUN/test_predictions.csv"
done
