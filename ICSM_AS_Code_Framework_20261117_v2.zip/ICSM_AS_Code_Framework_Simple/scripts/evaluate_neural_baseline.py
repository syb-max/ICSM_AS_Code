#!/usr/bin/env python3
"""Evaluate a named neural baseline. Test split requires a frozen selection manifest."""
from __future__ import annotations
import argparse,csv,json,hashlib
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from icsm_as.core.physics_data import PhysicsDataset
from icsm_as.core.capacity_teacher import capacity_validated
from icsm_as.models.baselines.registry import build_baseline

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def collate(rows): return {k:torch.stack([r[k] for r in rows]) if torch.is_tensor(rows[0][k]) else rows[0][k] for k in rows[0]}
def main():
 p=argparse.ArgumentParser();p.add_argument('--checkpoint',required=True);p.add_argument('--data_h5',required=True);p.add_argument('--output',required=True);p.add_argument('--split',type=int,default=1,choices=[1,2]);p.add_argument('--selection_manifest');p.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu');a=p.parse_args()
 ckpt_path=Path(a.checkpoint).resolve(); ckpt=torch.load(ckpt_path,map_location='cpu',weights_only=True)
 if a.split==2:
  if not a.selection_manifest: raise ValueError('Test evaluation requires --selection_manifest created after validation selection')
  manifest=json.loads(Path(a.selection_manifest).read_text(encoding='utf-8'))
  if manifest['checkpoint_sha256']!=sha(ckpt_path): raise ValueError('Checkpoint SHA256 does not match frozen manifest')
  if manifest['data_sha256']!=sha(a.data_h5): raise ValueError('Dataset SHA256 does not match frozen manifest')
  lock=Path(a.output).with_suffix('.test_opened.json'); lock.parent.mkdir(parents=True,exist_ok=True)
  with lock.open('x',encoding='utf-8') as f: json.dump({'manifest':str(Path(a.selection_manifest).resolve()),'checkpoint_sha256':sha(ckpt_path),'data_sha256':sha(a.data_h5)},f,indent=2)
 ds=PhysicsDataset(a.data_h5,split=a.split,require_teacher=(a.split!=2)); kwargs=dict(ckpt.get('model_kwargs',{})); kwargs.update(n_tx=ds.n_tx,n_sel=ds.n_sel)
 model=build_baseline(ckpt['model_name'],**kwargs).to(a.device); model.load_state_dict(ckpt['state_dict']); model.eval()
 loader=DataLoader(ds,batch_size=1,shuffle=False,num_workers=0,collate_fn=collate); rows=[]
 with torch.no_grad():
  for host in loader:
   batch={k:v.to(a.device) for k,v in host.items() if torch.is_tensor(v)}; pred=model(batch); subset=model.select(pred,k=ds.n_sel)[0].cpu().numpy()
   g=host['G_tx_real'][0].numpy()+1j*host['G_tx_imag'][0].numpy(); rho=float(host['snr_reference_linear'][0]); cap=capacity_validated(g,rho,subset,ds.n_sel)
   greedy=float(host['greedy_capacity'][0]); hq=float(host['hq_capacity'][0])
   rows.append({'sample_id':int(host['sample_id'][0]),'site_id':int(host['site_id'][0]),'snr_reference_db':float(host['snr_reference_db'][0]),'method':ckpt['model_name'],'capacity':cap,'NCR':cap/greedy if greedy>0 else '', 'R_C_HQ':cap/hq if hq>0 else '', 'selected_ports':' '.join(map(str,subset.tolist()))})
 Path(a.output).parent.mkdir(parents=True,exist_ok=True)
 with open(a.output,'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 ds.close();print(f'Wrote {len(rows)} rows: {a.output}')
if __name__=='__main__':main()
